@echo off
setlocal

set "ROOT_DIR=%~dp0"
set "SERVICE_DIR=%ROOT_DIR%voice-service"
set "SOURCE_SELECTOR=%ROOT_DIR%scripts\select-download-source.ps1"
set "SOURCE_CONFIG=%SERVICE_DIR%\.download-source.json"

if not exist "%SERVICE_DIR%\setup-local-engine.bat" (
  echo [JouJou Voice Engine] setup-local-engine.bat was not found.
  echo Please make sure the package was extracted correctly.
  pause
  exit /b 1
)

if not exist "%SOURCE_SELECTOR%" (
  echo [JouJou Voice Engine] select-download-source.ps1 was not found.
  echo Please make sure the package was extracted correctly.
  pause
  exit /b 1
)

powershell -NoProfile -ExecutionPolicy Bypass -File "%SOURCE_SELECTOR%" -OutputPath "%SOURCE_CONFIG%"
if %ERRORLEVEL% NEQ 0 (
  echo [JouJou Voice Engine] Download source detection failed. Continuing with the official source.
)

call "%SERVICE_DIR%\setup-local-engine.bat"

endlocal
pause
