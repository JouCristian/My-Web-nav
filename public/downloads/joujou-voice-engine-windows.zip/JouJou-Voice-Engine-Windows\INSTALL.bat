@echo off
setlocal

set "ROOT_DIR=%~dp0"
set "SERVICE_DIR=%ROOT_DIR%voice-service"

if not exist "%SERVICE_DIR%\setup-local-engine.bat" (
  echo [JouJou Voice Engine] setup-local-engine.bat was not found.
  echo Please make sure the package was extracted correctly.
  pause
  exit /b 1
)

call "%SERVICE_DIR%\setup-local-engine.bat"

endlocal
pause
